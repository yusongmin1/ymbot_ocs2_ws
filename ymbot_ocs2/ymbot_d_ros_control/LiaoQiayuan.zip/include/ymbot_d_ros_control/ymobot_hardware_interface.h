#ifndef YMBOT_HW_INTERFACE
#define YMBOT_HW_INTERFACE
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/robot_hw.h>
#include <controller_manager/controller_manager.h>
#include <ros/ros.h>
#include <memory>
#include <string>
#include <vector>
#include <chrono>
#include <thread>

using namespace std;

namespace Mobilemanipulate
{
#define joint_num 20
class YMBOTDHW : public hardware_interface::RobotHW 
{
        public:
        using Clock = std::chrono::high_resolution_clock;
        using Duration = std::chrono::duration<double>;
        // UR5HW(ros::NodeHandle& nh);
        YMBOTDHW(ros::NodeHandle& nh);
        ~YMBOTDHW();
        void init();
        void update(const ros::TimerEvent& e);
        void read();
        void write(ros::Duration elapsed_time);

        void setPositionDesired(double command,int i)
        {
                joint_position_command_[i]=command;
        }

        ros::Publisher pub;
        ros::ServiceClient client;     
        // 电机补偿角，与 urdf 模型的初始姿态以及实际机器人的姿态有关  左 右 躯干 ，数值需要修改
        std::vector<double> joints_offset_angle = {1.82373, 180.374, 182.23,  183.763, 190.074, 171.002, 182.214,
                                                148.821, 26.9604, 170.145, 7.196,   1.19751, 242.721, 176.638,
                                                184.922, 181.434, 212.086, 174.133, 186.279, 183.406};
        hardware_interface::JointStateInterface     joint_state_interface_;
        hardware_interface::PositionJointInterface  position_joint_interface_;
        hardware_interface::EffortJointInterface    effort_joint_interface_;

        std::vector<string> joint_name_;  
        vector<double> joint_position_;
        vector<double> joint_velocity_;
        vector<double> joint_effort_;
        vector<double> joint_position_command_;
        vector<double> joint_effort_command_;
        vector<double> joint_velocity_command_;

        ros::NodeHandle nh_;
        ros::Timer non_realtime_loop_;
        ros::Duration elapsed_time_;
        double loop_hz_;
        std::shared_ptr<controller_manager::ControllerManager> controller_manager_;

                // Timing
        double cycleTimeErrorThreshold_{}, loopHz_{};
        std::thread loopThread_;
        std::atomic_bool loopRunning_{};
        ros::Duration elapsedTime_;
        Clock::time_point lastTime_;


};




}
#endif