#include <ymbot_d_ros_control/ymobot_hardware_interface.h>
#include<thread>

namespace Mobilemanipulate
{
YMBOTDHW::YMBOTDHW(ros::NodeHandle& nh):nh_(nh){
    init();
    controller_manager_.reset(new controller_manager::ControllerManager(this, nh_));
    loop_hz_=50;
    ros::Duration update_freq = ros::Duration(1.0/loop_hz_);
	
	
    non_realtime_loop_ = nh_.createTimer(update_freq, &YMBOTDHW::update, this);
}

YMBOTDHW::~YMBOTDHW() {
}

void YMBOTDHW::init() {
    joint_name_={
        "Left_Arm_Joint1","Left_Arm_Joint2","Left_Arm_Joint3","Left_Arm_Joint4","Left_Arm_Joint5","Left_Arm_Joint6","Left_Arm_Joint7",
        "Right_Arm_Joint1","Right_Arm_Joint2","Right_Arm_Joint3","Right_Arm_Joint4","Right_Arm_Joint5","Right_Arm_Joint6","Right_Arm_Joint7",
        "Body_Joint1","Body_Joint2","Body_Joint3","Body_Joint4","Neck_Joint1","Neck_Joint2"
    };
    joint_position_.resize(joint_num,0.0);
    joint_velocity_.resize(joint_num,0.0);
    joint_effort_.resize(joint_num,0.0);
    joint_position_command_.resize(joint_num,0.0);
    for(int i=0;i<joint_num;i++)
    {
        // Create joint state interface
        hardware_interface::JointStateHandle jointStateHandle(joint_name_[i], &joint_position_[i], &joint_velocity_[i], &joint_effort_[i]);
        joint_state_interface_.registerHandle(jointStateHandle);

        // Create position joint interface
        hardware_interface::JointHandle jointPositionHandle(jointStateHandle, &joint_position_command_[i]);
        position_joint_interface_.registerHandle(jointPositionHandle);
    }
    // Register all joints interfaces    
    registerInterface(&joint_state_interface_);
    registerInterface(&position_joint_interface_);
}

void YMBOTDHW::update(const ros::TimerEvent& e) {
    elapsed_time_ = ros::Duration(e.current_real - e.last_real);
    read();
    controller_manager_->update(ros::Time::now(), elapsed_time_);
    write(elapsed_time_);
}

void YMBOTDHW::read() {


        

}

void YMBOTDHW::write(ros::Duration elapsed_time) {
    // std::cout<<"cnm\n";
    joint_position_=joint_position_command_;
}
}


using namespace Mobilemanipulate;
int main(int argc, char** argv)
{
    ros::init(argc, argv, "ymbot_d_ros_control_sim");
    ros::NodeHandle nh;
    //ros::AsyncSpinner spinner(4);  
    ros::MultiThreadedSpinner spinner(2); 
    YMBOTDHW ROBOT(nh);
    //spinner.start();
    spinner.spin();
    //ros::spin();
    return 0;
}
